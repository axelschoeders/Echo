# Echo Glasses (iOS companion for ECHO)

Small SwiftUI app that connects Ray-Ban Meta glasses to your existing ECHO AI.
**Status: written against Meta's official docs, but never compiled or run.** Expect to fix a few compiler
errors on the first build (see "Likely first-build errors").

## What it does
- Registers with the Meta AI app and connects to the glasses through Meta's Wearables Device Access Toolkit (DAT).
- Shows connection status on an arc-reactor screen.
- On "Hey Echo, wat zie je?" (or the button) it takes a photo through the glasses, sends it to your AI service, shows and speaks the answer.
- Plain questions work too (text only).
- **Simulation mode** (default on): fake connection plus a test image, no glasses and no Meta SDK needed. You can pick any photo as the fake camera.

Not included: ECHO's weather, news and app-maker. Those stay in the web app, unchanged.

## 1. You need a Mac, once
Xcode only runs on macOS. Options without owning one:
1. **GitHub Actions (compile check only).** Push this whole folder to a GitHub repo. `.github/workflows/ios-build.yml` builds the app on a macOS runner and shows compiler errors under *Actions*. Gives you a compile result, but not an installable app.
2. **Rented cloud Mac** (MacinCloud and similar): open Xcode over remote desktop, build and install on your iPhone via a cable only works if the USB is forwarded, which many services don't allow. TestFlight avoids this (next point).
3. **Installing on your iPhone** needs a signed build. Realistic route: Apple Developer Program (paid, yearly), Archive in Xcode, upload to TestFlight, install on the iPhone from the TestFlight app.

## 2. Build
On the Mac:
```bash
brew install xcodegen
cd ios-companion
xcodegen generate          # creates EchoGlasses.xcodeproj and resolves the Meta SDK package
open EchoGlasses.xcodeproj
```
In Xcode: select the *EchoGlasses* target, Signing & Capabilities, choose your Team. Change the bundle ID if Apple says `nl.echo.glasses` is taken.

No XcodeGen? Create a new iOS App project (SwiftUI, name EchoGlasses), delete the template files, drag in the `EchoGlasses` folder, replace its Info.plist with `Config/Info.plist`, then File > Add Package Dependencies > `https://github.com/facebook/meta-wearables-dat-ios` and add `MWDATCore` and `MWDATCamera`.

Without the SDK package the app still compiles (stub backend) and runs in simulation mode.

## 3. Pair with ECHO
1. In ECHO (web): Instellingen, fill provider and key, **Opslaan**, then **Koppel bril-app**. The config is now on the clipboard.
2. In Echo Glasses: Instellingen, **Plak**, then **Bewaar**.
3. Set a **Beeldmodel** that can read images (e.g. a Gemini model). ECHO's default Groq `gpt-oss-20b` is text-only, so photo questions would fail without this. Model names change; copy the current name from your provider's dashboard.

The key goes into the iOS Keychain and is sent only to the https URL you configured.

## 4. Real glasses
1. Ray-Ban Meta (Gen 1/2) with up-to-date firmware, Meta AI app installed and updated.
2. Meta AI app: Settings > your glasses > **Developer Mode** on (it can switch off after firmware updates).
3. Turn **Simulatiemodus** off, tap **Verbind**. Meta AI opens to approve the app and the camera permission, then returns to Echo Glasses.
4. If it hangs on "Wachten op bril": Developer Mode off, glasses folded/out of range, or Bluetooth off.

`MetaAppID` is `0` (Developer Mode). Publishing to other people needs a project and release channel at wearables.developer.meta.com.

## 5. Voice
- Speech recognition and speech output use Apple's frameworks (Dutch). When the glasses are connected as a Bluetooth audio device, iOS should route mic and speaker through them. Not verified on hardware; if audio stays on the phone, check the route in Control Center.
- DAT's own audio streaming is marked experimental and not for production publishing, so it is not used.
- "Hey Echo" only works while the app is open and the screen is on (iOS limit, same as the web app).

## Likely first-build errors
Meta's SDK is a developer preview and its docs contain small inconsistencies between versions. Check against the current API reference (https://wearables.developer.meta.com/docs/reference/ios_swift/dat/latest) if you see:
- `DATBackend.swift`: `startRegistration()` (written as `try await`; one Meta sample shows it without `await`), `PermissionStatus` case `.granted`, `capturePhoto(format:)` return value, `StreamState` cases.
- Package product names `MWDATCore` / `MWDATCamera` in `project.yml`.
- Deployment target: set to 17.0; Meta's docs mention 16+ in one place and 17.2 for the Display sample.
Meta also offers a docs MCP server (`https://mcp.developer.meta.com/wearables`, tool `search_dat_docs`) you can connect to an AI coding tool for exact symbols.

## Privacy and terms
- Photos are taken only when a command asks for it, shown on screen, and uploaded to your AI provider (an indicator shows while sending).
- Using the SDK means accepting Meta's Wearables Developer Terms. By default the SDK sends Meta usage analytics and crash reports; to opt out add `Analytics` / `CrashReporting` > `OptOut` = YES under the `MWDAT` key in `Config/Info.plist` (see the SDK README).

## Layout
```
Config/Info.plist          DAT + permission keys
project.yml                XcodeGen spec
EchoGlasses/
  EchoGlassesApp.swift     entry point, Wearables.configure(), URL callback
  AppModel.swift           state + wake word + command flow
  Glasses/                 GlassesBackend protocol, DATBackend (real), SimulatedBackend
  AI/                      EchoAIClient (same endpoint/persona as ECHO), config, Keychain
  Voice/                   SpeechListener, Speaker
  UI/                      ContentView, ReactorView, SettingsView
```
