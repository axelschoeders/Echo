import AVFoundation
import Speech

/// Continuous Dutch speech recognition. Emits one utterance after ~1.3 s of silence.
/// Foreground only (iOS does not allow always-on listening for third-party apps).
@MainActor
final class SpeechListener: ObservableObject {
    var onUtterance: ((String) -> Void)?
    @Published private(set) var isRunning = false
    @Published var lastError: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "nl-NL"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var debounce: Task<Void, Never>?
    private var latest = ""
    private var wantRunning = false
    private var generation = 0

    static func authorize() async -> Bool {
        let status = await withCheckedContinuation { (c: CheckedContinuation<SFSpeechRecognizerAuthorizationStatus, Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0) }
        }
        guard status == .authorized else { return false }
        return await AVAudioApplication.requestRecordPermission()
    }

    func start() {
        guard !wantRunning else { return }
        wantRunning = true
        beginSession()
    }

    func stop() {
        wantRunning = false
        teardown()
        isRunning = false
    }

    // MARK: private

    private func beginSession() {
        guard wantRunning else { return }
        guard let recognizer, recognizer.isAvailable else {
            lastError = "Spraakherkenning is niet beschikbaar. Zet Siri en Dicteren aan."
            wantRunning = false; isRunning = false
            return
        }
        teardown()
        generation += 1
        let gen = generation
        do {
            Speaker.configureAudioSession()
            let req = SFSpeechAudioBufferRecognitionRequest()
            req.shouldReportPartialResults = true
            request = req
            Self.installTap(on: engine.inputNode, request: req)
            engine.prepare()
            try engine.start()
            isRunning = true
            task = Self.startTask(recognizer: recognizer, request: req) { [weak self] text, isFinal, failed in
                Task { @MainActor in self?.onResult(text, isFinal: isFinal, failed: failed, gen: gen) }
            }
        } catch {
            lastError = "Microfoon starten mislukt: \(error.localizedDescription)"
            wantRunning = false; isRunning = false
        }
    }

    private func onResult(_ text: String?, isFinal: Bool, failed: Bool, gen: Int) {
        guard gen == generation, wantRunning else { return }
        if let text, !text.isEmpty {
            latest = text
            debounce?.cancel()
            debounce = Task { [weak self] in
                try? await Task.sleep(nanoseconds: 1_300_000_000)
                if !Task.isCancelled { self?.flush() }
            }
        }
        if isFinal || failed { flush() }
    }

    private func flush() {
        let text = latest.trimmingCharacters(in: .whitespacesAndNewlines)
        latest = ""
        teardown()
        if !text.isEmpty { onUtterance?(text) }
        if wantRunning {
            Task { [weak self] in
                try? await Task.sleep(nanoseconds: 300_000_000)
                self?.beginSession()
            }
        }
    }

    private func teardown() {
        debounce?.cancel()
        generation += 1                      // invalidates callbacks from the old task
        task?.cancel()
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        request = nil
        task = nil
    }

    // Created in nonisolated context so the audio-thread callbacks are not main-actor bound.
    private nonisolated static func installTap(on input: AVAudioInputNode,
                                               request: SFSpeechAudioBufferRecognitionRequest) {
        input.removeTap(onBus: 0)
        let format = input.outputFormat(forBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            request.append(buffer)
        }
    }

    private nonisolated static func startTask(
        recognizer: SFSpeechRecognizer,
        request: SFSpeechAudioBufferRecognitionRequest,
        handler: @escaping @Sendable (String?, Bool, Bool) -> Void
    ) -> SFSpeechRecognitionTask {
        recognizer.recognitionTask(with: request) { result, error in
            handler(result?.bestTranscription.formattedString, result?.isFinal ?? false, error != nil)
        }
    }
}
