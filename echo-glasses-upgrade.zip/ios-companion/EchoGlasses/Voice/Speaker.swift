import AVFoundation

/// Text-to-speech (Dutch). Audio goes to whatever route iOS has active, which is
/// the glasses when they are connected as a Bluetooth audio device.
@MainActor
final class Speaker: NSObject, AVSpeechSynthesizerDelegate {
    var muted = false
    private let synth = AVSpeechSynthesizer()
    private var waiter: CheckedContinuation<Void, Never>?

    override init() {
        super.init()
        synth.delegate = self
    }

    static func configureAudioSession() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playAndRecord, mode: .default,
                           options: [.allowBluetooth, .allowBluetoothA2DP, .defaultToSpeaker])
        try? s.setActive(true)
    }

    func speak(_ text: String) async {
        guard !muted else { return }
        stop()
        Self.configureAudioSession()
        let u = AVSpeechUtterance(string: text)
        u.voice = AVSpeechSynthesisVoice.speechVoices().first { $0.language == "nl-BE" }
            ?? AVSpeechSynthesisVoice(language: "nl-NL")
        await withCheckedContinuation { cont in
            waiter = cont
            synth.speak(u)
        }
    }

    func stop() {
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        finish()
    }

    private func finish() {
        let w = waiter
        waiter = nil
        w?.resume()
    }

    nonisolated func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) {
        Task { @MainActor in self.finish() }
    }
    nonisolated func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) {
        Task { @MainActor in self.finish() }
    }
}
