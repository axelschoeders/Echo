import SwiftUI

@main
struct EchoGlassesApp: App {
    @StateObject private var model = AppModel()

    init() {
        configureWearablesSDK()   // Wearables.configure(); no-op if the SDK package is missing
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .onOpenURL { url in
                    // Registration callback from the Meta AI app.
                    Task { await model.handle(url: url) }
                }
        }
    }
}
