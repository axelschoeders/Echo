import UIKit

enum AIClientError: LocalizedError {
    case notConfigured, insecureURL, badResponse
    case http(Int, hadImage: Bool)

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Ik heb nog geen AI-configuratie. Open Instellingen en plak de configuratie uit ECHO."
        case .insecureURL:
            return "De API-URL moet met https beginnen."
        case .badResponse:
            return "Ik kreeg een onverwacht antwoord van de AI-dienst."
        case .http(let code, let hadImage):
            return hadImage
                ? "AI-dienst gaf fout \(code). Controleer of het beeldmodel foto's ondersteunt (Instellingen)."
                : "AI-dienst gaf fout \(code)."
        }
    }
}

/// Talks to the same OpenAI-compatible endpoint as ECHO's web app, with the same persona.
/// The key is sent only to the https URL the user configured.
actor EchoAIClient {
    private var history: [[String: Any]] = []   // text only, last 8 messages (like ECHO)
    private let session = URLSession(configuration: .ephemeral)

    func reset() { history.removeAll() }

    func ask(_ text: String, image: Data?, config: EchoConfig) async throws -> String {
        guard config.isComplete else { throw AIClientError.notConfigured }
        guard let url = URL(string: config.url), url.scheme?.lowercased() == "https" else {
            throw AIClientError.insecureURL
        }

        var userContent: Any = text
        if let image {
            userContent = [
                ["type": "text", "text": text],
                ["type": "image_url",
                 "image_url": ["url": "data:image/jpeg;base64,\(image.base64EncodedString())"]]
            ] as [[String: Any]]
        }
        let model = (image != nil && !config.visionModel.isEmpty) ? config.visionModel : config.model

        let who = config.name.isEmpty ? "de gebruiker" : config.name
        let now = Date().formatted(date: .abbreviated, time: .shortened)
        let system = "Je bent Echo, een persoonlijke spraakassistent in de stijl van Jarvis, voor \(who). "
            + "Antwoord in het Nederlands, kort (maximaal 2 of 3 zinnen), als gesproken taal, zonder opmaak of emoji. "
            + "De gebruiker draagt een slimme bril. Als er een foto bijzit, beschrijf dan kort wat je ziet en beantwoord de vraag. "
            + "Nu: \(now)."

        var messages: [[String: Any]] = [["role": "system", "content": system]]
        messages += history
        messages.append(["role": "user", "content": userContent])

        var req = URLRequest(url: url, timeoutInterval: 60)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(config.key)", forHTTPHeaderField: "Authorization")
        req.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": model, "messages": messages, "max_tokens": 1500
        ] as [String: Any])

        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw AIClientError.badResponse }
        guard (200..<300).contains(http.statusCode) else {
            throw AIClientError.http(http.statusCode, hadImage: image != nil)
        }
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = obj["choices"] as? [[String: Any]],
              let message = choices.first?["message"] as? [String: Any],
              let content = message["content"] as? String
        else { throw AIClientError.badResponse }

        let answer = content.trimmingCharacters(in: .whitespacesAndNewlines)
        history.append(["role": "user", "content": image == nil ? text : "[foto] " + text])
        history.append(["role": "assistant", "content": answer])
        history = Array(history.suffix(8))
        return answer
    }
}

enum ImageUtil {
    /// Downscale to max 1024 px and re-encode as JPEG to keep uploads small.
    static func jpegForAI(_ data: Data, maxSide: CGFloat = 1024) -> Data {
        guard let img = UIImage(data: data) else { return data }
        let longest = max(img.size.width, img.size.height)
        let scale = min(1, maxSide / longest)
        let size = CGSize(width: img.size.width * scale, height: img.size.height * scale)
        let format = UIGraphicsImageRendererFormat.default()
        format.scale = 1
        let out = UIGraphicsImageRenderer(size: size, format: format).image { _ in
            img.draw(in: CGRect(origin: .zero, size: size))
        }
        return out.jpegData(compressionQuality: 0.7) ?? data
    }
}
