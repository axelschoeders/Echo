import Foundation

/// Same settings ECHO uses: an OpenAI-compatible chat endpoint, model and key.
/// `visionModel` is extra: the model used when a photo is attached.
struct EchoConfig: Codable, Equatable {
    var url = ""
    var model = ""
    var key = ""
    var name = ""
    var visionModel = ""

    var isComplete: Bool { !url.isEmpty && !model.isEmpty && !key.isEmpty }

    private static let account = "config"

    static func load() -> EchoConfig {
        guard let d = Keychain.get(account: account),
              let c = try? JSONDecoder().decode(EchoConfig.self, from: d) else { return EchoConfig() }
        return c
    }

    func save() {
        if let d = try? JSONEncoder().encode(self) { Keychain.set(d, account: Self.account) }
    }

    static func wipe() { Keychain.delete(account: account) }

    enum ImportError: LocalizedError {
        case notEcho, insecure
        var errorDescription: String? {
            switch self {
            case .notEcho:  return "Dit is geen ECHO-configuratie. Gebruik 'Koppel bril-app' in ECHO."
            case .insecure: return "De API-URL moet met https:// beginnen."
            }
        }
    }

    /// Reads the JSON that ECHO's "Koppel bril-app" button puts on the clipboard.
    /// Keeps the existing `visionModel`.
    mutating func apply(echoJSON text: String) throws {
        guard let data = text.trimmingCharacters(in: .whitespacesAndNewlines).data(using: .utf8),
              let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              (o["echo"] as? Int) == 1,
              let url = o["url"] as? String, let model = o["model"] as? String,
              let key = o["key"] as? String, !key.isEmpty
        else { throw ImportError.notEcho }
        guard url.lowercased().hasPrefix("https://") else { throw ImportError.insecure }
        self.url = url
        self.model = model
        self.key = key
        self.name = (o["name"] as? String) ?? ""
    }
}
