import UIKit

// Real glasses via Meta's Wearables Device Access Toolkit (developer preview).
// API usage follows Meta's iOS integration guide (see README-XCODE.md).
// If the SDK package is missing, a stub keeps the project compiling.

#if canImport(MWDATCore) && canImport(MWDATCamera)
import MWDATCore
import MWDATCamera

/// Set by `configureWearablesSDK()`; shown in the UI if configuration failed.
var wearablesConfigError: String?

/// Call once at app launch.
func configureWearablesSDK() {
    do { try Wearables.configure() }
    catch { wearablesConfigError = "SDK-configuratie mislukt: \(error.localizedDescription)" }
}

/// Lets the frame callback (not main-actor) decide cheaply whether to convert a frame.
private final class Throttle: @unchecked Sendable {
    private let lock = NSLock()
    private var last = Date.distantPast
    private let interval: TimeInterval
    init(_ interval: TimeInterval) { self.interval = interval }
    func pass() -> Bool {
        lock.lock(); defer { lock.unlock() }
        let now = Date()
        if now.timeIntervalSince(last) >= interval { last = now; return true }
        return false
    }
}

@MainActor
final class DATBackend: GlassesBackend {
    var onStatus: ((GlassesStatus) -> Void)?
    var onFrame: ((UIImage) -> Void)?

    private let wearables = Wearables.shared
    private var deviceSession: DeviceSession?
    private var camera: Camera?
    private var stream: MWDATCamera.Stream?
    private var tokens: [Any] = []          // listener tokens must stay alive
    private var tasks: [Task<Void, Never>] = []
    private var latestFrame: UIImage?
    private var photoWaiter: CheckedContinuation<Data, Error>?
    private var wantConnect = false
    private var starting = false
    private let throttle = Throttle(0.5)

    // MARK: connect / disconnect

    func connect() async {
        wantConnect = true
        onStatus?(.registering)
        observeRegistration()
        do {
            if case .registered = wearables.registrationState {
                await startSession()
            } else {
                // Opens the Meta AI app. The callback arrives via handle(url:),
                // then the registration observer starts the session.
                try await wearables.startRegistration()
            }
        } catch {
            onStatus?(.error("Registratie mislukt: \(error.localizedDescription)"))
        }
    }

    func disconnect() {
        wantConnect = false
        tasks.forEach { $0.cancel() }
        tasks.removeAll()
        tokens.removeAll()
        camera?.stop()
        deviceSession?.stop()
        stream = nil; camera = nil; deviceSession = nil
        failPendingPhoto(GlassesError.notConnected)
        onStatus?(.disconnected)
    }

    func handle(url: URL) async {
        _ = try? await wearables.handleUrl(url)
    }

    // MARK: registration

    private var observing = false
    private func observeRegistration() {
        guard !observing else { return }
        observing = true
        let t = Task { [weak self] in
            guard let self else { return }
            for await state in self.wearables.registrationStateStream() {
                if case .registered = state, self.wantConnect, self.deviceSession == nil {
                    await self.startSession()
                }
            }
        }
        tasks.append(t)
    }

    // MARK: session + camera

    private func startSession() async {
        guard !starting, deviceSession == nil else { return }
        starting = true
        defer { starting = false }
        do {
            onStatus?(.connecting)

            var permission = try await wearables.checkPermissionStatus(.camera)
            if permission != .granted {
                permission = try await wearables.requestPermission(.camera)
            }
            guard permission == .granted else {
                onStatus?(.error("Camera-toestemming geweigerd in Meta AI"))
                return
            }

            let selector = AutoDeviceSelector(wearables: wearables)
            let session = try wearables.createSession(deviceSelector: selector)

            let errTask = Task { [weak self] in
                for await error in session.errorStream() {
                    self?.onStatus?(.error(error.localizedDescription))
                }
            }
            tasks.append(errTask)

            try session.start()
            guard await waitUntilStarted(session, seconds: 25) else {
                session.stop()
                onStatus?(.error("Sessie niet gestart. Staat Developer Mode aan en is de bril in de buurt?"))
                return
            }

            let config = StreamConfiguration(videoCodec: .raw, resolution: .medium, frameRate: 24)
            guard let cam = try session.addCamera(config: config) else {
                onStatus?(.error("Camera niet beschikbaar"))
                return
            }
            let st = cam.stream
            deviceSession = session
            camera = cam
            stream = st

            tokens.append(st.statePublisher.listen { [weak self] state in
                Task { @MainActor in self?.apply(streamState: state) }
            })
            let throttle = self.throttle
            tokens.append(st.videoFramePublisher.listen { [weak self] frame in
                guard throttle.pass(), let image = frame.makeUIImage() else { return }
                Task { @MainActor in
                    self?.latestFrame = image
                    self?.onFrame?(image)
                }
            })
            tokens.append(st.photoDataPublisher.listen { [weak self] photo in
                let data = photo.data
                Task { @MainActor in self?.photoArrived(data) }
            })

            st.start()
        } catch {
            onStatus?(.error(error.localizedDescription))
        }
    }

    private func waitUntilStarted(_ session: DeviceSession, seconds: Double) async -> Bool {
        await withTaskGroup(of: Bool.self) { group in
            group.addTask {
                for await state in session.stateStream() {
                    if state == .started { return true }
                    if state == .stopped { return false }
                }
                return false
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                return false
            }
            let result = await group.next() ?? false
            group.cancelAll()
            return result
        }
    }

    private func apply(streamState state: StreamState) {
        switch state {
        case .streaming:        onStatus?(.streaming)
        case .waitingForDevice: onStatus?(.waitingForDevice)
        case .starting:         onStatus?(.connecting)
        case .paused:           onStatus?(.paused)
        case .stopped:          if wantConnect { onStatus?(.waitingForDevice) } else { onStatus?(.disconnected) }
        default:                break
        }
    }

    // MARK: photo

    func capturePhoto() async throws -> Data {
        guard let stream else { throw GlassesError.notConnected }
        return try await withCheckedThrowingContinuation { cont in
            photoWaiter = cont
            _ = stream.capturePhoto(format: .jpeg)
            Task { [weak self] in
                try? await Task.sleep(nanoseconds: 8_000_000_000)
                guard let self, let waiter = self.photoWaiter else { return }
                self.photoWaiter = nil
                // Fallback: newest video frame instead of failing outright.
                if let data = self.latestFrame?.jpegData(compressionQuality: 0.9) {
                    waiter.resume(returning: data)
                } else {
                    waiter.resume(throwing: GlassesError.timeout)
                }
            }
        }
    }

    private func photoArrived(_ data: Data) {
        guard let waiter = photoWaiter else { return }
        photoWaiter = nil
        waiter.resume(returning: data)
    }

    private func failPendingPhoto(_ error: Error) {
        guard let waiter = photoWaiter else { return }
        photoWaiter = nil
        waiter.resume(throwing: error)
    }
}

#else

var wearablesConfigError: String? = "Meta-SDK ontbreekt (alleen simulatie beschikbaar)"
func configureWearablesSDK() {}

@MainActor
final class DATBackend: GlassesBackend {
    var onStatus: ((GlassesStatus) -> Void)?
    var onFrame: ((UIImage) -> Void)?
    func connect() async { onStatus?(.error(GlassesError.sdkMissing.localizedDescription)) }
    func disconnect() { onStatus?(.disconnected) }
    func capturePhoto() async throws -> Data { throw GlassesError.sdkMissing }
    func handle(url: URL) async {}
}

#endif
