import UIKit

/// Development mode without glasses and without the Meta SDK.
/// Shows a fake connection sequence and uses a test image as the "camera".
@MainActor
final class SimulatedBackend: GlassesBackend {
    var onStatus: ((GlassesStatus) -> Void)?
    var onFrame: ((UIImage) -> Void)?

    /// Optional: a photo chosen by the user to act as what the glasses "see".
    var customImage: UIImage? {
        didSet { if connected, let img = customImage { onFrame?(img) } }
    }

    private var connected = false
    private var loop: Task<Void, Never>?

    func connect() async {
        connected = false
        for status in [GlassesStatus.registering, .connecting, .waitingForDevice] {
            onStatus?(status)
            try? await Task.sleep(nanoseconds: 600_000_000)
        }
        connected = true
        onStatus?(.streaming)
        onFrame?(currentImage())
        loop = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                guard let self, self.connected else { return }
                self.onFrame?(self.currentImage())
            }
        }
    }

    func disconnect() {
        connected = false
        loop?.cancel()
        onStatus?(.disconnected)
    }

    func capturePhoto() async throws -> Data {
        guard connected else { throw GlassesError.notConnected }
        try? await Task.sleep(nanoseconds: 400_000_000)   // pretend the shutter takes a moment
        guard let data = currentImage().jpegData(compressionQuality: 0.9) else { throw GlassesError.timeout }
        return data
    }

    func handle(url: URL) async {}

    private func currentImage() -> UIImage {
        if let c = customImage { return c }
        if let url = Bundle.main.url(forResource: "sim_scene", withExtension: "jpg"),
           let img = UIImage(contentsOfFile: url.path) { return img }
        let size = CGSize(width: 504, height: 896)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            UIColor(red: 0.04, green: 0.12, blue: 0.2, alpha: 1).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            let text = "SIMULATIE" as NSString
            text.draw(at: CGPoint(x: 150, y: 420), withAttributes: [
                .font: UIFont.systemFont(ofSize: 36, weight: .light),
                .foregroundColor: UIColor.cyan])
        }
    }
}
