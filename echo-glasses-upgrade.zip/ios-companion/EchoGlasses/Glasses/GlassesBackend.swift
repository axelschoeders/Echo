import UIKit

/// Connection state shown in the UI, independent of which backend is active.
enum GlassesStatus: Equatable {
    case disconnected
    case registering
    case connecting
    case waitingForDevice
    case streaming
    case paused
    case error(String)

    var label: String {
        switch self {
        case .disconnected:     return "Niet verbonden"
        case .registering:      return "Registreren bij Meta AI…"
        case .connecting:       return "Verbinden…"
        case .waitingForDevice: return "Wachten op bril…"
        case .streaming:        return "Verbonden · camera actief"
        case .paused:           return "Gepauzeerd door de bril"
        case .error(let m):     return "Fout: \(m)"
        }
    }

    var isLive: Bool { self == .streaming }
}

enum GlassesError: LocalizedError {
    case notConnected, timeout, sdkMissing

    var errorDescription: String? {
        switch self {
        case .notConnected: return "De bril is niet verbonden. Tik op Verbind."
        case .timeout:      return "De bril gaf geen foto terug. Probeer het nog eens."
        case .sdkMissing:   return "De Meta-SDK is niet toegevoegd aan dit project."
        }
    }
}

/// The only surface the rest of the app knows about. Two implementations:
/// `DATBackend` (real glasses, Meta DAT SDK) and `SimulatedBackend` (no hardware).
@MainActor
protocol GlassesBackend: AnyObject {
    var onStatus: ((GlassesStatus) -> Void)? { get set }
    var onFrame: ((UIImage) -> Void)? { get set }

    func connect() async
    func disconnect()
    /// Returns JPEG data of a still photo from the glasses camera.
    func capturePhoto() async throws -> Data
    /// Forward URLs opened by the Meta AI app (registration callback).
    func handle(url: URL) async
}
