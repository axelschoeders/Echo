import SwiftUI

/// Iron Man-style arc reactor. Colour and speed follow the connection state.
struct ReactorView: View {
    let color: Color
    let active: Bool

    private func angle(_ t: TimeInterval, period: Double) -> Double {
        (t.truncatingRemainder(dividingBy: period) / period) * 360
    }

    var body: some View {
        TimelineView(.animation) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate
            ZStack {
                Circle()
                    .fill(RadialGradient(colors: [color.opacity(0.45), color.opacity(0.03)],
                                         center: .center, startRadius: 4, endRadius: 115))
                Circle()
                    .stroke(color, lineWidth: 2)
                    .padding(6)
                    .shadow(color: color.opacity(0.8), radius: active ? 14 : 5)
                Circle()
                    .trim(from: 0, to: 0.8)
                    .stroke(color.opacity(0.85),
                            style: StrokeStyle(lineWidth: 3, lineCap: .round, dash: [10, 6]))
                    .padding(20)
                    .rotationEffect(.degrees(angle(t, period: active ? 6 : 24)))
                Circle()
                    .stroke(color.opacity(0.6), style: StrokeStyle(lineWidth: 2, dash: [2, 8]))
                    .padding(40)
                    .rotationEffect(.degrees(-angle(t, period: active ? 9 : 36)))
                ForEach(0..<3) { i in
                    Capsule()
                        .fill(color.opacity(0.7))
                        .frame(width: 10, height: 30)
                        .offset(y: -34)
                        .rotationEffect(.degrees(Double(i) * 120 + angle(t, period: active ? 12 : 48)))
                }
                Circle()
                    .fill(color)
                    .frame(width: 30, height: 30)
                    .blur(radius: 2)
                    .scaleEffect(1 + (active ? 0.12 : 0.04) * sin(t * 3))
            }
            .frame(width: 230, height: 230)
        }
    }
}
