import SwiftUI
import PhotosUI

private let cyan = Color(red: 0.18, green: 0.89, blue: 1.0)
private let amber = Color(red: 1.0, green: 0.69, blue: 0.13)
private let dim = Color(red: 0.48, green: 0.6, blue: 0.68)

struct ContentView: View {
    @EnvironmentObject var m: AppModel
    @State private var showSettings = false
    @State private var typed = ""
    @State private var pick: PhotosPickerItem?

    private var reactorColor: Color {
        switch m.status {
        case .streaming: return cyan
        case .error: return .red
        case .disconnected: return dim
        default: return amber
        }
    }

    var body: some View {
        ZStack {
            RadialGradient(colors: [Color(red: 0.05, green: 0.13, blue: 0.21), Color(red: 0.02, green: 0.04, blue: 0.08)],
                           center: .init(x: 0.5, y: 0.3), startRadius: 10, endRadius: 600)
                .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 14) {
                    Text("ECHO · GLASSES")
                        .font(.system(size: 20, weight: .light))
                        .tracking(6)
                        .foregroundStyle(Color(red: 0.85, green: 0.95, blue: 1))
                        .padding(.top, 8)

                    Button(action: m.tapReactor) {
                        ReactorView(color: reactorColor, active: m.busy || m.status.isLive)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Praat met Echo")

                    VStack(spacing: 4) {
                        Text(m.status.label + (m.simulation ? "  [SIMULATIE]" : ""))
                            .foregroundStyle(reactorColor)
                            .multilineTextAlignment(.center)
                        Text(m.phase).font(.footnote).foregroundStyle(dim)
                    }

                    if m.uploading {
                        Label("Beeld wordt naar je AI-dienst gestuurd", systemImage: "arrow.up.circle")
                            .font(.footnote).foregroundStyle(amber)
                    }

                    if let img = m.lastImage {
                        Image(uiImage: img)
                            .resizable().scaledToFit()
                            .frame(maxHeight: 170)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(cyan.opacity(0.5), lineWidth: 1))
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        if !m.you.isEmpty { Text(m.you).foregroundStyle(dim) }
                        if !m.echo.isEmpty { Text(m.echo).foregroundStyle(Color(red: 0.85, green: 0.95, blue: 1)) }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    HStack(spacing: 8) {
                        EchoButton(m.isConnected ? "Verbreek" : "Verbind", accent: m.isConnected ? amber : cyan) {
                            m.isConnected ? m.disconnect() : m.connect()
                        }
                        EchoButton("Wat zie je?") {
                            Task { await m.run("Wat zie je? Beschrijf kort wat je ziet.") }
                        }
                        .disabled(!m.isConnected || m.busy)
                    }

                    HStack(spacing: 8) {
                        EchoButton("Hey Echo: \(m.wakeOn ? "aan" : "uit")", action: m.toggleWake)
                        EchoButton("Stem: \(m.muted ? "uit" : "aan")") { m.muted.toggle() }
                    }

                    Toggle("Simulatiemodus (geen bril nodig)", isOn: $m.simulation)
                        .tint(cyan).foregroundStyle(dim).font(.footnote)

                    if m.simulation {
                        PhotosPicker(selection: $pick, matching: .images) {
                            Text("Kies testfoto voor de 'camera'")
                                .font(.footnote).foregroundStyle(cyan)
                        }
                        .onChange(of: pick) { _, item in
                            Task {
                                if let d = try? await item?.loadTransferable(type: Data.self),
                                   let img = UIImage(data: d) { m.setSimulatedPhoto(img) }
                            }
                        }
                    }

                    HStack(spacing: 8) {
                        TextField("Typ hier wat je wilt…", text: $typed)
                            .padding(12)
                            .background(Color(red: 0.04, green: 0.1, blue: 0.16), in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(red: 0.11, green: 0.23, blue: 0.31)))
                            .submitLabel(.send)
                            .onSubmit(send)
                        EchoButton("Stuur", action: send).frame(width: 80)
                    }

                    EchoButton("Instellingen") { showSettings = true }

                    if let n = m.notice {
                        Text(n).font(.footnote).foregroundStyle(amber).multilineTextAlignment(.center)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView().environmentObject(m) }
    }

    private func send() {
        m.sendTyped(typed)
        typed = ""
    }
}

struct EchoButton: View {
    let title: String
    var accent: Color = Color(red: 0.85, green: 0.95, blue: 1)
    let action: () -> Void

    init(_ title: String, accent: Color = Color(red: 0.85, green: 0.95, blue: 1), action: @escaping () -> Void) {
        self.title = title; self.accent = accent; self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .foregroundStyle(accent)
                .background(Color(red: 0.04, green: 0.1, blue: 0.16), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color(red: 0.11, green: 0.23, blue: 0.31)))
        }
    }
}
