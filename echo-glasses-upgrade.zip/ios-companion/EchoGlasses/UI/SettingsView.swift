import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var m: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var draft = EchoConfig()
    @State private var message = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Configuratie uit ECHO") {
                    PasteButton(payloadType: String.self) { strings in
                        guard let s = strings.first else { return }
                        do {
                            try draft.apply(echoJSON: s)
                            message = "Configuratie geplakt. Tik op Bewaar."
                        } catch {
                            message = error.localizedDescription
                        }
                    }
                    Text("In ECHO: Instellingen > Opslaan > Koppel bril-app. Plak hier daarna.")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section("AI-dienst") {
                    TextField("API-URL (https)", text: $draft.url)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    TextField("Model", text: $draft.model)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("Beeldmodel (voor foto's)", text: $draft.visionModel)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    SecureField("API-sleutel", text: $draft.key)
                    TextField("Naam", text: $draft.name)
                    Text("Het beeldmodel moet foto's kunnen lezen (bijv. een Gemini-model). Leeg = gewoon model.")
                        .font(.footnote).foregroundStyle(.secondary)
                }

                Section {
                    Button("Bewaar") {
                        m.saveConfig(draft)
                        dismiss()
                    }
                    Button("Wis configuratie", role: .destructive) {
                        m.wipeConfig()
                        draft = EchoConfig()
                    }
                }

                if !message.isEmpty { Section { Text(message).font(.footnote) } }

                Section("Privacy") {
                    Text("De sleutel staat in de iOS-Keychain en gaat alleen naar de URL hierboven. Foto's worden alleen verstuurd als je er om vraagt (bijv. 'wat zie je') en naar dezelfde AI-dienst.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Instellingen")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Sluit") { dismiss() } } }
            .onAppear { draft = m.config }
        }
    }
}
