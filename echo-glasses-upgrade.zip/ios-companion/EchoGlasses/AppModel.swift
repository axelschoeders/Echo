import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    // UI state
    @Published var status: GlassesStatus = .disconnected
    @Published var phase = ""                 // what Echo is doing right now
    @Published var lastImage: UIImage?
    @Published var you = ""
    @Published var echo = ""
    @Published var busy = false
    @Published var uploading = false          // true while a photo is on its way to the AI service
    @Published var wakeOn = false
    @Published var muted = false { didSet { speaker.muted = muted } }
    @Published var notice: String?
    @Published var config = EchoConfig.load()
    @Published var simulation: Bool {
        didSet {
            guard simulation != oldValue else { return }
            UserDefaults.standard.set(simulation, forKey: "simulation")
            switchBackend()
        }
    }

    let listener = SpeechListener()
    private let speaker = Speaker()
    private let ai = EchoAIClient()
    private var backend: GlassesBackend
    private var armedUntil = Date.distantPast
    private var singleShot = false

    // Same wake phrase as the ECHO web app.
    private static let wakePattern = #"\b(hey|hé|hee|hei|hai|hallo)[\s,]*(echo|eko|ecco|ekko)\b[\s,.!?]*"#
    private static let visionPattern =
        #"\b(wat zie je|zie je|kijk|beschrijf|wat is dit|wat is dat|wat staat|lees dit|lees dat|foto|omgeving|om me heen)\b"#

    init() {
        // Default to simulation until the user turns it off.
        let sim = UserDefaults.standard.object(forKey: "simulation") as? Bool ?? true
        simulation = sim
        backend = sim ? SimulatedBackend() : DATBackend()
        wire()
        listener.onUtterance = { [weak self] text in self?.heard(text) }
        if !sim, let err = wearablesConfigError { notice = err }
        phase = idleText
    }

    var isConnected: Bool { status.isLive }
    private var idleText: String { wakeOn ? "Zeg \"Hey Echo\" (app open laten)" : "Tik op de cirkel om te praten" }

    // MARK: backend

    private func wire() {
        backend.onStatus = { [weak self] s in self?.status = s }
        backend.onFrame = { [weak self] img in self?.lastImage = img }
    }

    private func switchBackend() {
        backend.disconnect()
        backend = simulation ? SimulatedBackend() : DATBackend()
        wire()
        status = .disconnected
        lastImage = nil
        notice = simulation ? nil : wearablesConfigError
    }

    func connect() { Task { await backend.connect() } }
    func disconnect() { backend.disconnect() }
    func handle(url: URL) async { await backend.handle(url: url) }

    func setSimulatedPhoto(_ image: UIImage) {
        (backend as? SimulatedBackend)?.customImage = image
        lastImage = image
    }

    // MARK: settings

    func saveConfig(_ new: EchoConfig) {
        config = new
        new.save()
        Task { await ai.reset() }
        notice = "Opgeslagen"
    }

    func wipeConfig() {
        EchoConfig.wipe()
        config = EchoConfig()
        Task { await ai.reset() }
    }

    // MARK: voice

    func toggleWake() {
        if wakeOn {
            wakeOn = false
            listener.stop()
            phase = idleText
        } else {
            Task {
                guard await SpeechListener.authorize() else {
                    notice = "Geef toegang tot microfoon en spraakherkenning in iOS-instellingen."
                    return
                }
                wakeOn = true
                listener.start()
                phase = idleText
            }
        }
    }

    func tapReactor() {
        Task {
            guard await SpeechListener.authorize() else {
                notice = "Geef toegang tot microfoon en spraakherkenning in iOS-instellingen."
                return
            }
            armedUntil = Date().addingTimeInterval(10)
            if !wakeOn { singleShot = true; listener.start() }
            phase = "Ik luister…"
        }
    }

    private func heard(_ raw: String) {
        guard !busy else { return }
        if singleShot {
            singleShot = false
            listener.stop()
            Task { await run(raw) }
            return
        }
        if let r = raw.range(of: Self.wakePattern, options: [.regularExpression, .caseInsensitive]) {
            let rest = String(raw[r.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !rest.isEmpty { Task { await run(rest) } }
            else { armedUntil = Date().addingTimeInterval(8); phase = "Ja? Ik luister…" }
            return
        }
        if Date() < armedUntil {
            armedUntil = .distantPast
            Task { await run(raw) }
        }
    }

    // MARK: main flow

    func run(_ text: String) async {
        guard !busy else { return }
        busy = true
        you = "Jij: " + text
        echo = ""
        listener.stop()                       // don't hear our own voice

        var reply: String
        do {
            guard config.isComplete else { throw AIClientError.notConfigured }
            var imageForAI: Data?
            if needsCamera(text) {
                phase = "Foto maken…"
                let raw = try await backend.capturePhoto()
                lastImage = UIImage(data: raw) ?? lastImage
                imageForAI = ImageUtil.jpegForAI(raw)
                uploading = true
            }
            phase = "Even denken…"
            reply = try await ai.ask(text, image: imageForAI, config: config)
        } catch {
            reply = error.localizedDescription
        }

        uploading = false
        echo = "Echo: " + reply
        phase = "Echo spreekt…"
        await speaker.speak(reply)
        busy = false
        phase = idleText
        if wakeOn { listener.start() }
    }

    func sendTyped(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        Task { await run(t) }
    }

    private func needsCamera(_ text: String) -> Bool {
        text.lowercased().range(of: Self.visionPattern, options: .regularExpression) != nil
    }
}
