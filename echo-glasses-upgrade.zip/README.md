# ECHO + Ray-Ban Meta

- `echo-app/`  the existing ECHO web app (PWA). Only additive changes: a "Koppel bril-app" button in Instellingen, a readme section, a service-worker cache bump. Deploy this folder as before (Netlify Drop).
- `ios-companion/`  the new Swift/SwiftUI companion app. See `ios-companion/README-XCODE.md`. Do not upload this folder to your web host.
- `.github/workflows/ios-build.yml`  optional compile check on GitHub's macOS runners.
