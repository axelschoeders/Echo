#!/usr/bin/env python3
"""Echo (app + bridge in één): bedien Samsung-tv's (LAN) en deze Windows-pc vanaf je iPhone.

- Draait op je Windows-pc, alleen bereikbaar vanaf je thuisnetwerk (privé IP-adressen).
- Elke opdracht vereist een geheime token.
- Er is geen "voer willekeurige opdracht uit": alleen de acties hieronder.
"""
import ctypes
import hmac
import ipaddress
import json
import secrets
import socket
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# Naast het .exe-bestand (of script) staan config.json en de tv-tokens.
HERE = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
# De webbestanden zitten in het .exe-bestand zelf (PyInstaller) of in de map web/.
WEB = Path(getattr(sys, "_MEIPASS", HERE)) / "web"
CONFIG = HERE / "config.json"
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".png": "image/png", ".webmanifest": "application/manifest+json"}
WIN = sys.platform == "win32"

# Toetsen die naar de tv gestuurd mogen worden (Samsung remote key names).
TV_KEYS = {
    "KEY_POWER", "KEY_VOLUP", "KEY_VOLDOWN", "KEY_MUTE", "KEY_CHUP", "KEY_CHDOWN",
    "KEY_HOME", "KEY_MENU", "KEY_SOURCE", "KEY_UP", "KEY_DOWN", "KEY_LEFT", "KEY_RIGHT",
    "KEY_ENTER", "KEY_RETURN", "KEY_EXIT", "KEY_PLAY", "KEY_PAUSE", "KEY_STOP",
    "KEY_FF", "KEY_REWIND", "KEY_INFO", "KEY_GUIDE",
}

# Windows media/volume virtual-key codes
VK = {"volume_up": 0xAF, "volume_down": 0xAE, "mute": 0xAD,
      "play_pause": 0xB3, "next": 0xB0, "prev": 0xB1}


# ---------------------------------------------------------------- config

def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))     # no packet is sent
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def first_run():
    cfg = {"port": 8765, "token": secrets.token_hex(12), "tvs": [],
           "apps": {"Kladblok": "notepad.exe", "Rekenmachine": "calc.exe"}}
    print("Eerste keer: ik stel je tv's in. Laat leeg om te stoppen.")
    print("(IP en MAC vind je op de tv bij Instellingen > Algemeen > Netwerk > Netwerkstatus.)")
    while sys.stdin.isatty():
        name = input("Naam van de tv (bijv. Woonkamer): ").strip()
        if not name:
            break
        ip = input("  IP-adres (bijv. 192.168.1.50): ").strip()
        mac = input("  MAC-adres (voor aanzetten, mag leeg): ").strip()
        cfg["tvs"].append({"name": name, "ip": ip, "mac": mac})
    CONFIG.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    return cfg


def load_config():
    if not CONFIG.exists():
        return first_run()
    return json.loads(CONFIG.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- tv

def find_tv(cfg, name):
    for tv in cfg["tvs"]:
        if tv["name"] == name:
            return tv
    raise ValueError("Onbekende tv")


def tv_send(tv, key):
    from samsungtvws import SamsungTVWS   # pip install samsungtvws
    safe = "".join(c for c in tv["name"] if c.isalnum()) or "tv"
    remote = SamsungTVWS(host=tv["ip"], port=8002, token_file=str(HERE / f"tv-{safe}.token"),
                         name="EchoBridge", timeout=8, key_press_delay=0.3)
    try:
        remote.send_key(key)
    finally:
        try:
            remote.close()
        except Exception:
            pass


def tv_wake(tv):
    mac = tv.get("mac", "").replace(":", "").replace("-", "").strip()
    if len(mac) != 12 or any(c not in "0123456789abcdefABCDEF" for c in mac):
        raise ValueError("Geen geldig MAC-adres voor deze tv in config.json")
    packet = bytes.fromhex("FF" * 6 + mac * 16)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.sendto(packet, ("255.255.255.255", 9))


# ---------------------------------------------------------------- pc

def press(vk):
    u = ctypes.windll.user32
    u.keybd_event(vk, 0, 0, 0)
    u.keybd_event(vk, 0, 2, 0)


def pc_action(cfg, action):
    if not WIN:
        raise RuntimeError("PC-opdrachten werken alleen op Windows")
    if action in VK:
        press(VK[action])
    elif action == "lock":
        ctypes.windll.user32.LockWorkStation()
    elif action == "sleep":
        subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
    elif action == "shutdown":
        subprocess.Popen(["shutdown", "/s", "/t", "30"])      # 30 s om te annuleren
    elif action == "restart":
        subprocess.Popen(["shutdown", "/r", "/t", "30"])
    elif action == "cancel_shutdown":
        subprocess.Popen(["shutdown", "/a"])
    elif action.startswith("open:") and action[5:] in cfg.get("apps", {}):
        subprocess.Popen([cfg["apps"][action[5:]]])             # alleen apps uit config.json
    else:
        raise ValueError("Onbekende actie")


# ---------------------------------------------------------------- http

def make_handler(cfg):
    class Handler(BaseHTTPRequestHandler):
        server_version = "EchoBridge"

        def log_message(self, fmt, *args):
            print(time.strftime("%H:%M:%S"), self.client_address[0], fmt % args)

        def send_json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def allowed(self):
            try:
                ip = ipaddress.ip_address(self.client_address[0])
            except ValueError:
                return False
            return ip.is_private or ip.is_loopback

        def authed(self):
            sent = self.headers.get("X-Echo-Token", "")
            ok = hmac.compare_digest(sent.encode(), cfg["token"].encode())
            if not ok:
                time.sleep(1)              # slows down guessing
            return ok

        def do_GET(self):
            if not self.allowed():
                return self.send_json(403, {"error": "alleen thuisnetwerk"})
            route = self.path.split("?")[0]
            if route == "/remote":
                route = "/remote.html"
            f = (WEB / route.lstrip("/")) if route != "/" else (WEB / "index.html")
            if f.suffix in MIME and f.parent == WEB and f.is_file():
                body = f.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", MIME[f.suffix])
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Frame-Options", "DENY")
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/api/state":
                if not self.authed():
                    return self.send_json(401, {"error": "token klopt niet"})
                self.send_json(200, {"tvs": [t["name"] for t in cfg["tvs"]],
                                     "apps": list(cfg.get("apps", {}).keys()),
                                     "windows": WIN})
            else:
                self.send_json(404, {"error": "niet gevonden"})

        def do_POST(self):
            if not self.allowed():
                return self.send_json(403, {"error": "alleen thuisnetwerk"})
            if not self.authed():
                return self.send_json(401, {"error": "token klopt niet"})
            try:
                n = int(self.headers.get("Content-Length", "0"))
                if n > 4096:
                    return self.send_json(413, {"error": "te groot"})
                data = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/api/tv":
                    key = data.get("key", "")
                    if key not in TV_KEYS:
                        raise ValueError("Toets niet toegestaan")
                    tv_send(find_tv(cfg, data.get("tv", "")), key)
                elif self.path == "/api/tv/wake":
                    tv_wake(find_tv(cfg, data.get("tv", "")))
                elif self.path == "/api/pc":
                    pc_action(cfg, str(data.get("action", "")))
                else:
                    return self.send_json(404, {"error": "niet gevonden"})
                self.send_json(200, {"ok": True})
            except ImportError:
                self.send_json(500, {"error": "samsungtvws ontbreekt (pip install samsungtvws)"})
            except (ValueError, RuntimeError) as e:
                self.send_json(400, {"error": str(e)})
            except Exception as e:                                 # tv offline, geweigerd, ...
                self.send_json(502, {"error": f"{type(e).__name__}: {e}"})

    return Handler


def main():
    cfg = load_config()
    server = ThreadingHTTPServer(("0.0.0.0", int(cfg["port"])), make_handler(cfg))
    url = f"http://{lan_ip()}:{cfg['port']}/#t={cfg['token']}"
    print("\nEcho Bridge draait. Laat dit venster open.")
    print("Open dit adres op je iPhone (zelfde wifi) en zet het op je beginscherm:\n")
    print("   " + url + "\n")
    print("Niet delen: de token na #t= geeft toegang tot je pc en tv.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
