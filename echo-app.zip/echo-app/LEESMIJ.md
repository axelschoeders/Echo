# Echo (app + bridge in één)

E�n programma op je Windows-pc dat Echo (spraakassistent) én de tv/pc-afstandsbediening aanbiedt.

## Starten
- Snel proberen: dubbelklik `start-echo.bat` (Python nodig).
- Eén .exe maken: dubbelklik `bouw-exe.bat` op een Windows-pc. Resultaat: `dist\Echo.exe`.
  `config.json` en de tv-tokens komen naast de .exe te staan.
- Het venster toont een adres met `#t=...`. Open dat in Safari op je iPhone.
  - `/`        = Echo
  - `/remote`  = TV & PC-afstandsbediening

## Let op
- Safari staat de microfoon/spraakherkenning alleen toe via https. Dit programma draait op http in je
  eigen wifi, dus spraak werkt daar waarschijnlijk niet. Typen, tv en pc werken wel. Wil je spraak,
  zet dan de map `web` online (Netlify/GitHub Pages) zoals in de oude LEESMIJ.
- Niet getest op Windows of met een echte Samsung-tv.
- De Meta Ray-Ban SDK zit er nog NIET in (zie chat).
