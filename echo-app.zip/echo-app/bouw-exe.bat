@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt --quiet
python -m PyInstaller --onefile --name Echo --add-data "web;web" --collect-all samsungtvws echo_app.py
echo.
echo Klaar: dist\Echo.exe
pause
